class User
  include Mongoid::Document
end
